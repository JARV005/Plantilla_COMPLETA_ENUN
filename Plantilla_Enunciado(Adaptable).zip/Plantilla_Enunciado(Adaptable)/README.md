# SQL Database Management System – CRUD + CSV Upload

## 📌 Project Description
This project is a simple SQL-based data management system developed for **ExpertSoft**, designed to help organize and manage financial or customer-related data coming from disorganized Excel/CSV files.  
It includes:
- A PostgreSQL/MySQL database.
- A REST API built with **Express.js** for CRUD operations.
- A CSV data upload script for bulk inserts.
- A minimal **Bootstrap**-based frontend dashboard for managing entities.
- Integration between frontend and backend via API calls.

---

## 🎯 Objectives
- Store normalized data in a relational database.
- Perform **Create**, **Read**, **Update**, and **Delete** operations on an entity (`users` by default, adaptable to other entities).
- Load data from a `.csv` file directly into the database.
- Provide a simple and functional frontend for managing data.

---

## 🛠️ Technologies Used
- **Backend:** Node.js, Express.js
- **Frontend:** HTML, Bootstrap, JavaScript (Fetch API)
- **Database:** PostgreSQL or MySQL
- **Other Tools:** `csv-parser`, `fs` for CSV file handling

---

## 📂 Project Structure
project/
│── backend/
│ ├── index.js # Main server file
│ ├── db.js # Database connection
│ ├── routes/
│ │ └── users.js # CRUD API routes
│ ├── scripts/
│ │ └── load_csv.js # Script to load users from CSV
│
│── frontend/
│ ├── index.html # Dashboard page
│ ├── js/
│ │ └── main.js # Frontend CRUD logic
│
│── database/
│ ├── schema.sql # Base database/table creation script
│ └── users.csv # Example CSV data file
│
└── README.md



---

## ⚙️ Installation & Execution

### 1️⃣ Clone the repository
```bash
git clone https://github.com/your-username/your-repo.git
cd your-repo
2️⃣ Install dependencies

npm install
3️⃣ Configure the database connection
Edit backend/db.js with your database credentials:


const { Client } = require("pg");

const client = new Client({
  user: "your_username",
  host: "localhost",
  database: "your_database",
  password: "your_password",
  port: 5432 // Change if using MySQL or another port
});

module.exports = client;
4️⃣ Create the database & tables
Run the SQL script provided:


# PostgreSQL
psql -U your_username -d your_database -f database/schema.sql

# MySQL
mysql -u your_username -p your_database < database/schema.sql
📥 Bulk Upload from CSV
Place your CSV file inside the database/ folder (default name: users.csv).

Run the script:


node backend/scripts/load_csv.js
The data will be inserted into the users table, skipping duplicates (by id).

🖥️ Running the Backend Server

node backend/index.js
The API will be available at:


http://localhost:3000/api/users
🌐 Using the Frontend
Open frontend/index.html in your browser.

You will be able to:

Create a new user.

Read (view) all users.

Update an existing user.

Delete a user.

📌 Advanced Queries (Postman)
The API should also include endpoints for:

Total paid by each customer.

Pending invoices with customer and transaction info.

Transactions by platform (Nequi/Daviplata).

These can be tested directly in Postman once implemented.

📄 Normalization Explanation
The provided data (originally in Excel) should be analyzed and normalized manually according to:

First Normal Form (1NF) – Remove duplicate columns and ensure atomic values.

Second Normal Form (2NF) – Remove partial dependencies.

Third Normal Form (3NF) – Remove transitive dependencies.

The resulting model should be drawn using draw.io (or similar) and included as an image or PDF.