const API_URL = "http://localhost:3000/api/users";

// Fetch and display users
async function loadUsers() {
  const res = await fetch(API_URL);
  const users = await res.json();
  const tableBody = document.querySelector("#usersTable tbody");
  tableBody.innerHTML = "";
  users.forEach(user => {
    tableBody.innerHTML += `
      <tr>
        <td>${user.id}</td>
        <td>${user.name}</td>
        <td>${user.email}</td>
        <td>${user.age}</td>
        <td>
          <button class="btn btn-warning btn-sm" onclick="editUser(${user.id})">Edit</button>
          <button class="btn btn-danger btn-sm" onclick="deleteUser(${user.id})">Delete</button>
        </td>
      </tr>
    `;
  });
}

// Create or update user
async function saveUser() {
  const id = document.querySelector("#userId").value;
  const name = document.querySelector("#name").value;
  const email = document.querySelector("#email").value;
  const age = document.querySelector("#age").value;

  const user = { name, email, age: parseInt(age) };

  if (id) {
    // Update
    await fetch(`${API_URL}/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(user)
    });
  } else {
    // Create
    await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(user)
    });
  }

  document.querySelector("#userForm").reset();
  document.querySelector("#userId").value = "";
  loadUsers();
}

// Edit user
async function editUser(id) {
  const res = await fetch(`${API_URL}/${id}`);
  const user = await res.json();
  document.querySelector("#userId").value = user.id;
  document.querySelector("#name").value = user.name;
  document.querySelector("#email").value = user.email;
  document.querySelector("#age").value = user.age;
}

// Delete user
async function deleteUser(id) {
  await fetch(`${API_URL}/${id}`, { method: "DELETE" });
  loadUsers();
}

document.querySelector("#userForm").addEventListener("submit", e => {
  e.preventDefault();
  saveUser();
});

loadUsers();
