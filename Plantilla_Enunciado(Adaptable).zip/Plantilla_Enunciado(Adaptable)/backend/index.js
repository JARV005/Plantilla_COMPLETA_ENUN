const express = require("express");
const cors = require("cors");
const usersRoutes = require("./routes/users"); // ahora es users.js

const app = express();
app.use(cors());
app.use(express.json());

app.use("/api/users", usersRoutes); // ruta ahora es /api/users

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
