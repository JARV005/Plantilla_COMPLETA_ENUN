const APP_URL = "http://localhost:3000/";

// GET
(async function index() {
  try {
    const res = await fetch(APP_URL+'users');
    const data = await res.json();
    console.log('GET:', data[0]);
    const tbody = document.getElementById('tbody');
    tbody.innerHTML = '';
    data[0].forEach(user => {
        tbody.innerHTML += `<tr>
                                <td>${user.id}</td>
                                <td>${user.first_name}</td>
                                <td>${user.last_name}</td>
                                <td>${user.email}</td>
                                <td>${user.username}</td>
                                <td>
                                  <a href="#" class="btn btn-sm btn-info" data-id="${user.id}">Detalles</a>
                                  <a href="#" class="btn btn-sm btn-warning edit" data-id="${user.id}">Editar</a>
                                  <a href="#" class="btn btn-sm btn-danger" data-id="${user.id}">Eliminar</a>
                                </td>
                            </tr>`
    });
  } catch (error) {
    console.error('Error en GET:', error);
  }
})()

//POST
async function store(event) {
      event.preventDefault();

      // Capturamos los valores de los campos del formulario
      const firstName = document.getElementById('first_name').value.trim();
      const lastName = document.getElementById('last_name').value.trim();
      const email = document.getElementById('email').value.trim();
      const username = document.getElementById('username').value.trim();
      const password = document.getElementById('password').value.trim();

      // Validaciones básicas
      if (!firstName || !lastName || !email || !username || !password) {
        alert('Todos los campos son obligatorios.');
        return;
      }

      // Validar formato de email
      const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
      if (!emailPattern.test(email)) {
        alert('El email no es válido.');
        return;
      }

      // Validar longitud de la contraseña
      if (password.length < 6) {
        alert('La contraseña debe tener al menos 6 caracteres.');
        return;
      }

      try {
        const res = await fetch(APP_URL + 'users', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            first_name: firstName,
            last_name: lastName,
            email: email,
            username: username,
            password: password,
          }),
        });

        const data = await res.json();

        if (res.ok) {
          // Si la creación fue exitosa, mostramos un mensaje de éxito
          alert('Usuario creado exitosamente!');
          document.getElementById('addUserForm').reset();
        } else {
          // Si ocurrió un error, mostramos el mensaje de error
          alert(data.error || 'Error al crear el usuario.');
        }
      } catch (error) {
        console.error('Error en POST:', error);
        alert('Error de red. Intenta nuevamente.');
      }
    }
document.getElementById('addUserForm').addEventListener('submit', store)

//PUT
async function update(event) {
  event.preventDefault();

  // Capturamos la ID del usuario desde el campo oculto
  const userId = document.getElementById('user_id').value;

  // Capturamos los valores de los campos del formulario
  const firstName = document.getElementById('first_name2').value.trim();
  const lastName = document.getElementById('last_name2').value.trim();
  const email = document.getElementById('email2').value.trim();
  const username = document.getElementById('username2').value.trim();
  const password = document.getElementById('password2').value.trim();

  // Validaciones básicas
  if (!firstName || !lastName || !email || !username || !password) {
    alert('Todos los campos son obligatorios.');
    return;
  }

  // Validar formato de email
  const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
  if (!emailPattern.test(email)) {
    alert('El email no es válido.');
    return;
  }

  // Validar longitud de la contraseña
  if (password.length < 6) {
    alert('La contraseña debe tener al menos 6 caracteres.');
    return;
  }

  try {
    const res = await fetch(APP_URL + 'users/' + userId, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        first_name: firstName,
        last_name: lastName,
        email: email,
        username: username,
        password: password,
      }),
    });

    const data = await res.json();

    if (res.ok) {
      alert('Usuario actualizado exitosamente!');
      // Limpiar formulario o redirigir, lo que prefieras
      document.getElementById('editUserForm').reset();
    } else {
      alert(data.error || 'Error al actualizar el usuario.');
    }
  } catch (error) {
    console.error('Error en PUT:', error);
    alert('Error de red. Intenta nuevamente.');
  }
}

// Añadimos el evento al formulario de edición
document.getElementById('editUserForm').addEventListener('submit', update);

// Asegúrate de que el DOM esté completamente cargado
document.addEventListener('DOMContentLoaded', function () {
  // Seleccionamos todos los botones "Editar" en la tabla
  const editButtons = document.querySelectorAll('.edit');
  
  // Asignamos el evento click a cada botón "Editar"
  editButtons.forEach(btn => {
    btn.addEventListener('click', async (event) => {
      const userId = event.target.getAttribute('data-id'); // Obtenemos la ID del usuario
      console.log(userId);
      
      try {
        // Hacemos una solicitud GET para obtener los datos del usuario
        const res = await fetch(APP_URL + 'users/' + userId);
        const data = await res.json();

        if (res.ok) {
          // Llenamos el formulario con los datos obtenidos
          document.getElementById('user_id').value = data.id;
          document.getElementById('first_name2').value = data.first_name;
          document.getElementById('last_name2').value = data.last_name;
          document.getElementById('email2').value = data.email;
          document.getElementById('username2').value = data.username;
          document.getElementById('password2').value = '';  // Dejamos la contraseña vacía para el usuario
        } else {
          alert(data.error || 'Error al cargar los datos del usuario.');
        }
      } catch (error) {
        console.error('Error al obtener los datos del usuario:', error);
        alert('Error de red. Intenta nuevamente.');
      }
    });
  });
});



//DELETE
async function deleteUser(userId) {
  // Confirmar la eliminación antes de proceder
  if (!confirm("¿Estás seguro de que deseas eliminar este usuario?")) {
    return;  // Si el usuario cancela, no hace nada
  }

  try {
    const res = await fetch(APP_URL + 'users/' + userId, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (res.ok) {
      // Si la eliminación fue exitosa, mostramos un mensaje de éxito
      console.log('DELETE: Usuario eliminado');
      // Aquí puedes, por ejemplo, eliminar al usuario de la lista en el frontend
      // o actualizar la vista para reflejar los cambios (eliminarlo del DOM)
      alert('Usuario eliminado exitosamente');
    } else {
      // Si ocurrió algún error, lo mostramos
      const data = await res.json();
      console.error('Error en DELETE:', data.error || 'Error desconocido');
      alert('No se pudo eliminar el usuario. Intenta nuevamente.');
    }
  } catch (error) {
    console.error('Error en DELETE:', error);
    alert('Error de red. Intenta nuevamente.');
  }
}
