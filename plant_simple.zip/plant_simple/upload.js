const fs = require('fs');
const csv = require('csv-parser');
const mysql = require('mysql2');

// Configuración de la conexión a MySQL
const connection = mysql.createConnection({
  host: '168.119.183.3',
  user: 'root',
  password: 'g0tIFJEQsKHm5$34Pxu1',
  database: 'jbrahian_ms',
  port: 3307,
});

async function uploadUsersCSV() {
  try {
    // Conectar a la base de datos
    connection.connect((err) => {
      if (err) {
        console.error('Error de conexión a la base de datos:', err);
        return;
      }
      console.log('Conexión a MySQL exitosa');
    });

    const users = [];
    fs.createReadStream('db.csv')
      .pipe(csv())
      .on('data', (data) => {
        users.push(data);
      })
      .on('end', async () => {
        for (const user of users) {
          // Consulta para insertar en la base de datos
          const query = `
            INSERT INTO users (username, email, password, first_name, last_name, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE 
                password = VALUES(password),
                first_name = VALUES(first_name),
                last_name = VALUES(last_name),
                created_at = VALUES(created_at);
            `;


          // Valores a insertar
          const values = [
            user.username,
            user.email,
            user.password,
            user.first_name,
            user.last_name,
            user.created_at,
          ];

          // Ejecutar la consulta
          connection.execute(query, values, (err, results) => {
            if (err) {
              console.error('Error al insertar usuarios:', err);
            }
          });
        }

        console.log('Usuarios cargados exitosamente.');
        
        // Cerrar la conexión
        connection.end();
      });
  } catch (err) {
    console.error('Error cargando usuarios:', err);
    connection.end();
  }
}

uploadUsersCSV();
