const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors')

const app = express();
app.use(cors());
app.use(express.json());

const pool = mysql.createPool({
  host: '168.119.183.3',      
  user: 'root',   
  password: 'g0tIFJEQsKHm5$34Pxu1', 
  database: 'jbrahian_ms', 
  port: 3307,
});

// Exponer el servidor en un puerto difinido.

app.listen(3000, () => {
  console.log('Servidor corriendo en http://localhost:3000');
});

//GET
app.get('/users', async (req, res) => {
  try {
    let result = await pool.query(`SELECT id, first_name, last_name, email, username
      FROM users;`
    );
    if (result.length === 0) {
      return res.status(404).json({ error: 'No se encontraron usuarios' });
    }
    return res.json(result);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Error al obtener los datos' });
  }
});

//GET user
app.get('/users/:id', async (req, res) => {
  const { id } = req.params;
  if (isNaN(id)) {
    return res.status(400).json({ error: 'El ID debe ser un número válido' });
  }
  try {
    let result = await pool.query(`SELECT id, first_name, last_name, email, username
      FROM users
      WHERE id = ?;`, [id]
    );
    if (result.length === 0) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }
    return res.json(result[0]);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Error al obtener los datos' });
  }
});


// POST /users
app.post('/users', async (req, res) => {
  const { first_name, last_name, email, username, password } = req.body;
  if (!first_name || !last_name || !email || !username || !password) {
    return res.status(400).json({ error: 'Todos los campos son obligatorios' });
  }
  try {
    const result = await pool.query(
      'INSERT INTO users (first_name, last_name, email, username, password) VALUES (?, ?, ?, ?, ?)',
      [first_name, last_name, email, username, password]
    );
    res.status(201).json({ message: 'Usuario creado exitosamente', userId: result.insertId });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al crear el usuario' });
  }
});


// PUT /users/:id
app.put('/users/:id', async (req, res) => {
  const { id } = req.params;
  const { first_name, last_name, email, username, password } = req.body;
  if (!first_name || !last_name || !email || !username || !password) {
    return res.status(400).json({ error: 'Todos los campos son obligatorios' });
  }
  if (isNaN(id)) {
    return res.status(400).json({ error: 'El ID debe ser un número válido' });
  }
  try {
    const result = await pool.query(
      `UPDATE users 
       SET first_name = ?, last_name = ?, email = ?, username = ?, password = ? 
       WHERE id = ?`,
      [first_name, last_name, email, username, password, id]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }
    res.json({ message: 'Usuario actualizado exitosamente' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al actualizar el usuario' });
  }
});



// DELETE /users/:id
app.delete('/users/:id', async (req, res) => {
  const { id } = req.params;
  if (isNaN(id)) {
    return res.status(400).json({ error: 'El ID debe ser un número válido' });
  }
  try {
    const result = await pool.query('DELETE FROM users WHERE id = ?', [id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }
    res.json({ message: 'Usuario eliminado exitosamente' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al eliminar el usuario' });
  }
});

